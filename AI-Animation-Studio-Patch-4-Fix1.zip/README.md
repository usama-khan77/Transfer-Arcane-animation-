# AI Animation Studio — Patch 4 (Sana app integration)

This patch builds on Patch 3 and adds the first Android-side Sana workflow:

- A one-time downloader for the official `taobao-mnn/MNN-Sana-Edit-V2` model files (about 1.66 GB according to the model repository). It stores them in app-private storage and keeps `.part` files so interrupted downloads can be resumed.
- A prompt field and multi-photo picker.
- Copies selected document URIs into app cache before native inference.
- Calls the Sana JNI session sequentially for each selected image, using CPU backend and 512×512 output settings as a conservative initial compatibility choice.
- Saves generated PNGs to the app's Pictures folder and to the Android gallery on Android 10+.
- Removes the optional ARM82 build flag so the native build does not deliberately request that optimization for this phone's initial compatibility test.

## Important limitations

This is an integration attempt, not a verified working release. The patch has not yet been built by GitHub Actions or tested on the Redmi Note 13. The native C++ integration from Patch 3 is still dependent on the current MNN `master` branch. The model download is approximately 1.66 GB and needs a stable connection and at least 2 GB free storage. Initial generation is set to 512×512 on CPU; it may be slow or run out of memory on Snapdragon 685. It does not promise 1080p, exact identity preservation, or reliable batch completion until tested.

If the build fails, keep the GitHub Actions error log; do not install an APK from a failed or unverified run. The app is intended to run inference locally after the model has been downloaded; the downloader itself needs internet access.


## Fix 1

The build workflow now installs Gradle 8.9 and runs `gradle assembleDebug`.
The repository does not contain a Gradle wrapper (`gradlew`), so the earlier
Patch 4 workflow command that tried to execute `./gradlew` would fail before
the Android build. This correction fixes that workflow issue only; it does
not mean the native Sana build has been compiled or tested.
